let USERNAME=process.env.USERNAME; // "Ravi"
console.log("Hello " + USERNAME);