var arguments=process.argv;
console.log("Hello "+arguments[2]);
