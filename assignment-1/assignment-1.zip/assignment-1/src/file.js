let file = require("./index.js")
console.log(file)
file.myFileWriter();
file.myFileReader();
file.myFileUpdater();
file.myFileReader();
file.myFileDeleter();
